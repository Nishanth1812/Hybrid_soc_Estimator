from __future__ import annotations

import logging
import time

import torch


class Trainer:

    def __init__(self, model, optimizer, loss_fn, device, lr_scheduler=None):

        self.model = model
        self.optimizer = optimizer
        self.loss_fn = loss_fn
        self.device = device
        self.lr_scheduler = lr_scheduler


    def train_epoch(
        self,
        dataloader,
        logger: logging.Logger | None = None,
        epoch: int | None = None,
        total_epochs: int | None = None,
    ):

        self.model.train()

        total_loss = 0.0
        total_batches = len(dataloader)
        progress_interval = max(1, total_batches // 10)
        started_at = time.perf_counter()

        for batch_index, (X, y) in enumerate(dataloader, start=1):

            X = X.to(self.device)
            y = y.to(self.device)

            self.optimizer.zero_grad()

            pred = self.model(X)

            loss = self.loss_fn(pred, y)

            loss.backward()

            torch.nn.utils.clip_grad_norm_(self.model.parameters(), 1.0)

            self.optimizer.step()

            total_loss += loss.item()

            if logger is not None and (
                batch_index == 1
                or batch_index % progress_interval == 0
                or batch_index == total_batches
            ):
                epoch_label = (
                    f"{epoch}/{total_epochs}"
                    if epoch is not None and total_epochs is not None
                    else str(epoch or "?")
                )
                logger.info(
                    "Epoch %s | batch %d/%d | loss=%.6f | elapsed=%.1fs",
                    epoch_label,
                    batch_index,
                    total_batches,
                    loss.item(),
                    time.perf_counter() - started_at,
                )

        return total_loss / total_batches

    def step_scheduler(self, val_loss):
        if self.lr_scheduler is not None:
            self.lr_scheduler.step(val_loss)


    def validate(self, dataloader):

        self.model.eval()

        total_loss = 0

        with torch.no_grad():

            for X, y in dataloader:

                X = X.to(self.device)
                y = y.to(self.device)

                pred = self.model(X)

                loss = self.loss_fn(pred, y)

                total_loss += loss.item()

        return total_loss / len(dataloader)
